import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyDNv1KoRyLApPgGya_GxRb9vrg6o7EZ_hM';
const genAI = new GoogleGenerativeAI(API_KEY);

const MAX_RETRIES = 2;
const RETRY_DELAY = 1000; // 1 second

async function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function getGeminiResponse(prompt: string, retryCount = 0): Promise<string> {
  if (!prompt.trim()) {
    throw new Error('Prompt cannot be empty');
  }

  try {
    const model = genAI.getGenerativeModel({ 
      model: 'gemini-2.0-flash',
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      },
    });

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    if (!text) {
      throw new Error('Empty response received from Gemini API');
    }

    return text;

  } catch (error) {
    // Log the full error for debugging
    console.error('Gemini API Error:', {
      error,
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });

    // Handle retries for specific errors
    if (retryCount < MAX_RETRIES && error instanceof Error) {
      const shouldRetry = 
        error.message.includes('rate limit') ||
        error.message.includes('timeout') ||
        error.message.includes('network');

      if (shouldRetry) {
        await delay(RETRY_DELAY * (retryCount + 1));
        return getGeminiResponse(prompt, retryCount + 1);
      }
    }

    // Provide specific error messages
    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        throw new Error('Invalid API key. Please check your configuration.');
      } else if (error.message.includes('network')) {
        throw new Error('Network error. Please check your internet connection.');
      } else if (error.message.includes('rate limit') || error.message.includes('quota')) {
        throw new Error('API rate limit reached. Please try again in a few moments.');
      } else if (error.message.includes('safety')) {
        throw new Error('The request was flagged by safety filters. Please modify your prompt and try again.');
      }
      
      // Throw the original error message if it's a known error
      throw new Error(`Gemini API Error: ${error.message}`);
    }

    // Generic error message as fallback
    throw new Error('Unable to get AI response. Please try again.');
  }
}