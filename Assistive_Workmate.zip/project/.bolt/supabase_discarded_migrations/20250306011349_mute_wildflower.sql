/*
  # Create task logs table and security policies

  1. New Tables
    - `task_logs`
      - `id` (uuid, primary key)
      - `task_type` (text)
      - `params` (jsonb)
      - `status` (text)
      - `result` (text, nullable)
      - `error` (text, nullable)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `completed_at` (timestamptz, nullable)

  2. Security
    - Enable RLS on `task_logs` table
    - Add policies for authenticated users to:
      - Read task logs
      - Create task logs
      - Update task logs
*/

-- Create the task_logs table if it doesn't exist
CREATE TABLE IF NOT EXISTS task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type text NOT NULL,
  params jsonb NOT NULL,
  status text NOT NULL,
  result text,
  error text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Enable RLS
ALTER TABLE task_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Users can read task logs"
  ON task_logs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create task logs"
  ON task_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update their task logs"
  ON task_logs
  FOR UPDATE
  TO authenticated
  USING (true);