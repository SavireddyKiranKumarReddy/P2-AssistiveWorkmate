import React, { useState, useEffect, KeyboardEvent } from 'react';
import { Send, Play, Loader2, Terminal, MessageSquare, AlertCircle, Menu, History, X, ChevronRight, ChevronLeft, CheckCircle2, Code, Cog } from 'lucide-react';
import { getGeminiResponse } from './lib/gemini';
import { parseAutomationTasks, executeAutomationTask } from './lib/automation';

interface AutomationStatus {
  isRunning: boolean;
  message: string;
  success?: boolean;
  error?: string;
  steps?: string[];
  currentStep?: number;
}

interface HistoryItem {
  query: string;
  response: string;
  timestamp: Date;
  status?: AutomationStatus;
}

const commonQueries = [
  "Check disk space",
  "List running applications",
  "Clean temporary files",
  "Check Windows updates",
  "Show system information",
  "Manage startup programs",
  "Check network status",
  "Power settings"
];

function App() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [automationStatus, setAutomationStatus] = useState<AutomationStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [suggestionIndex, setSuggestionIndex] = useState(0);
  const [isAutomating, setIsAutomating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setSuggestionIndex((prev) => (prev + 1) % commonQueries.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleKeyPress = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setAutomationStatus(null);
    setIsAutomating(false);
    
    try {
      const aiResponse = await getGeminiResponse(query);
      setResponse(aiResponse);
      setHistory(prev => [{
        query,
        response: aiResponse,
        timestamp: new Date()
      }, ...prev]);
      
    } catch (error) {
      setResponse('Sorry, I encountered an error while processing your request. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutomate = async () => {
    setIsAutomating(true);
    setAutomationStatus({ 
      isRunning: true, 
      message: 'Starting automation...',
      steps: ['Finding suggestion', 'Executing automation'],
      currentStep: 0 
    });
    
    try {
      const tasks = parseAutomationTasks(query);
      setAutomationStatus(prev => ({ ...prev!, currentStep: 1 }));
      
      for (const task of tasks) {
        const result = await executeAutomationTask(task);
        console.log('Automation result:', result);
      }

      setAutomationStatus({
        isRunning: false,
        message: 'Automation completed successfully',
        success: true,
        steps: [
          '✓ Suggestion found',
          '✓ Automation executed'
        ],
        currentStep: 2
      });

    } catch (error) {
      setAutomationStatus({
        isRunning: false,
        message: 'Automation failed',
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        steps: [
          '✕ Process failed',
          ''
        ],
        currentStep: 0
      });
    } finally {
      setIsAutomating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 transform ${isHistoryOpen ? 'translate-x-0' : '-translate-x-full'} w-72 bg-gray-800 shadow-lg transition-transform duration-300 ease-in-out z-20 border-r border-gray-700`}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <History className="h-5 w-5 text-blue-400" />
              <h2 className="text-lg font-semibold text-gray-100">History</h2>
            </div>
            <button onClick={() => setIsHistoryOpen(false)} className="text-gray-400 hover:text-gray-200">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="space-y-4">
            {history.map((item, index) => (
              <div key={index} className="group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 transform -skew-x-12 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors border border-gray-600 hover:border-gray-500">
                  <p className="text-sm font-medium text-gray-100">{item.query}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(item.timestamp).toLocaleString()}
                  </p>
                  {item.status && (
                    <div className={`mt-2 text-xs flex items-center space-x-1 ${
                      item.status.success ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {item.status.success ? (
                        <CheckCircle2 className="h-3 w-3" />
                      ) : (
                        <AlertCircle className="h-3 w-3" />
                      )}
                      <span>{item.status.message}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        {/* Header */}
        <header className="bg-gray-800 shadow-md border-b border-gray-700">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsHistoryOpen(!isHistoryOpen)}
                className="text-gray-400 hover:text-gray-200"
              >
                <Menu className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-2">
                <Terminal className="h-6 w-6 text-blue-400" />
                <h1 className="text-xl font-bold text-gray-100">ASSISTIVE WORKMATE</h1>
              </div>
            </div>
          </div>
        </header>

        <div className="flex h-[calc(100vh-4rem)]">
          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col">
            <main className="flex-1 overflow-y-auto p-4">
              {response && (
                <div className="max-w-3xl mx-auto bg-gray-800 rounded-lg shadow-lg p-6 mb-6 border border-gray-700">
                  <div className="flex items-start space-x-3">
                    <MessageSquare className="h-5 w-5 text-blue-400 mt-1" />
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-200 mb-2">Step-by-Step Guide</h3>
                      <p className="text-gray-300 whitespace-pre-wrap">{response}</p>
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end">
                    <button
                      onClick={handleAutomate}
                      disabled={isAutomating}
                      className="flex items-center space-x-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                    >
                      {isAutomating ? (
                        <>
                          <Loader2 className="h-5 w-5 animate-spin" />
                          <span>Automating...</span>
                        </>
                      ) : (
                        <>
                          <Play className="h-5 w-5" />
                          <span>Automate This</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </main>

            {/* Input Area */}
            <div className="border-t border-gray-700 bg-gray-800 p-4">
              {/* Quick Actions */}
              <div className="max-w-3xl mx-auto mb-4 overflow-hidden">
                <div className="relative">
                  <div className="flex space-x-2 animate-scroll">
                    {[...commonQueries, ...commonQueries].map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => setQuery(suggestion)}
                        className="flex-none px-4 py-2 bg-gray-700/50 text-sm text-gray-300 rounded-full hover:bg-gray-700 transition-colors border border-gray-600 hover:border-gray-500 hover:text-white whitespace-nowrap"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Input Form */}
              <form onSubmit={handleSubmit} className="max-w-3xl mx-auto relative">
                <textarea
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Describe what you want to do..."
                  className="w-full p-4 bg-gray-700/50 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none h-20 placeholder-gray-500"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  className="absolute bottom-3 right-3 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-110"
                >
                  {isLoading ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <Send className="h-5 w-5" />
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Task Progress Panel */}
          {automationStatus && (
            <div className="w-80 border-l border-gray-700 bg-gray-800 p-6">
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-200 mb-2">Automation Progress</h3>
                <p className="text-sm text-gray-400">{automationStatus.message}</p>
              </div>
              
              <div className="space-y-4">
                {automationStatus.steps?.map((step, index) => (
                  <div
                    key={index}
                    className={`flex items-center space-x-3 ${
                      index <= (automationStatus.currentStep ?? 0)
                        ? 'text-gray-200'
                        : 'text-gray-500'
                    }`}
                  >
                    {index < (automationStatus.currentStep ?? 0) ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500 flex-none" />
                    ) : index === (automationStatus.currentStep ?? 0) ? (
                      <div className="h-5 w-5 rounded-full border-2 border-blue-500 border-t-transparent animate-spin flex-none" />
                    ) : (
                      <div className="h-5 w-5 rounded-full border-2 border-gray-600 flex-none" />
                    )}
                    <span className="text-sm">{step}</span>
                  </div>
                ))}
              </div>

              {automationStatus.error && (
                <div className="mt-6 p-4 bg-red-900/20 border border-red-700/50 rounded-lg">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="h-5 w-5 text-red-400 flex-none mt-0.5" />
                    <p className="text-sm text-red-400">{automationStatus.error}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;